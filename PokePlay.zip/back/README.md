# PokéPlay

## Instalación

1. Clona este repositorio en tu máquina local:

`git clone <url_del_repositorio>`


2. Instala las dependencias del servidor ejecutando el siguiente comando en la carpeta raíz del proyecto:

`npm install`

`cd node`

`npm install`

`cd ../vue`

`npm install`

3. En la carpeta raíz realizaremos la siguiente acción:

`docker-compose up`

si no funciona de primeras ejecutar otra vez

4. Finalmente ejecutar la siguiente línea en la carpeta 'vue':

`npm run dev`