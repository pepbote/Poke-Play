const express = require('express');
const swaggerUi = require('swagger-ui-express');
const swaggerJsdoc = require("swagger-jsdoc");
const bodyParser = require('body-parser');
const { WebSocketServer } = require('ws');
const http = require('http');

const config = require("./config/config");
const UserRouter = require('./routes/user.route');
const UrlRouter = require('./routes/url.route');

// Crear la aplicación express
const app = express();
const port = config.PORT;

var cors = require('cors');
app.use(cors());

// Opciones de Swagger
const options = {
  swaggerDefinition: {
    info: {
      title: "User API",
      version: "1.0.0",
      description: "API para administrar usuarios y enlaces recortados",
    },
    host: "api.fmesasc.com",
    basePath: "/v1",
    schemes: ["https"],
  },
  apis: ["./routes/*.js"],
};
const specs = swaggerJsdoc(options);

// Usar el middleware body parser
app.use(bodyParser.json());
app.use(express.static('public'));

// Usar el router de usuarios
app.use('/api/users', UserRouter);

// Usar el router de URLs
app.use('/api/urls', UrlRouter);

// Usar Swagger
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(specs));

// Crear el servidor HTTP
const server = http.createServer(app);

// Crear el servidor WebSocket
const wss = new WebSocketServer({ server });

// Manejar conexiones WebSocket
wss.on('connection', (ws) => {
  ws.on('message', (message) => {
    wss.clients.forEach((client) => {
        client.send(JSON.stringify(JSON.parse(message)));
    });
  });
});

// Iniciar el servidor HTTP
server.listen(port, () => {
  console.log(`API server is listening on port ${port}`);
});
