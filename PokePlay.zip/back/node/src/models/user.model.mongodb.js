const User = require('./user.model');
const mongoClient = require('../services/mongodb.service');

class MongoDBUser extends User {
  constructor(database) {
    super(database);
    this.collection = mongoClient.db('PokePlay').collection('users');
    this.db = mongoClient.db('PokePlay');
  }

  async create(user, cb) {
    const result = await this.collection.insertOne(user);
    cb(null, result);
  }

  async get(id, cb) {
    console.log(typeof id);
    const result = await this.collection.findOne({ _id: id });
    if (!result) return cb(null, null);
    cb(null, result);
  }

  async getAll(cb) {
    const result = await this.collection.find().toArray();
    if (!result) return cb(null, null);
    cb(null, result);
  }

  async getUserByEmail(email, cb) {
    const result = await this.collection.findOne({ email: email });
    if (!result) return cb(null, null);
    cb(null, result);
  }

  async getIdByEmail(email) {
    const result = await this.collection.findOne({ email: email }, { projection: { _id: 1 } });
    return result && result._id.toString();
  }

  async update(id, updates, cb) {
    const result = await this.collection.updateOne({ _id: id }, { $set: updates });
    cb(null, result.modifiedCount > 0);
  }

  async delete(id, cb) {
    const result = await this.collection.deleteOne({ _id: id });
    cb(null, result.deletedCount > 0);
  }

  async getPoints(id, cb) {
    const result = await this.collection.findOne({ _id: id }, { projection: { points: 1 } });
    console.log(result);
    cb(null, result.points);
  }

  async addPoints(id, points, cb) {
    const result = await this.collection.updateOne(
      { _id: id },
      { $inc: { points: points } }
    );
    cb(null, result.modifiedCount > 0);
  }

  async getPokemons(id, cb) {
    const result = await this.collection.findOne({ _id: id }, { projection: { pokemons: 1 } });
    if (!result) return cb(null, null);
    cb(null, result.pokemons);
  }

  async getPokemon(id, idPokemon, cb) {
    const result = await this.collection.findOne({ _id: id }, { projection: { pokemons: 1 } });
    const pokemon = result.pokemons.find(pokemon => pokemon.id === idPokemon);
    console.log(pokemon)
    cb(null, pokemon);
  }

  async addPokemon(id, pokemon, cb) {
    const result = await this.collection.updateOne(
      { _id: id },
      { $push: { pokemons: pokemon } }
    );
    cb(null, result.modifiedCount > 0);
  }

  async deletePokemon(id, name, cb) {
    const result = await this.collection.updateOne(
      { _id: id},
      { $pull: { "pokemons": { "name": name } } }
    )
    console.log(result);
    cb(null, result.modifiedCount > 0);
  }

  async updatePokemons(id, pokemons, cb) {
    const result = await this.collection.updateOne(
      { _id: id },
      { $set: { pokemons: pokemons.pokemons  } }
    );
    cb(null, result.modifiedCount > 0);
  }

  async getMessages(cb) {
    const result = await this.db.collection('chat').find().toArray();
    if (!result) return cb(null, null);
    cb(null, result);
  }

  async addMessage(message, cb) {
    const result = await this.db.collection('chat').insertOne(message);
    if (!result) return cb(null, null);
    cb(null, result);
  }
}

module.exports = MongoDBUser;
