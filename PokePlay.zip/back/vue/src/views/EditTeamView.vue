<template>
  <div id="app">
    <HeaderComponent />
    <main>
      <div class="title">
        <p>Editar equipo</p>
      </div>
      <div v-if="pokemonTeam.length > 0" id="equipoActual">
        <p>Equipo Actual</p>
        <div class="card-container">
          <PokemonCard v-for="(pokemon, index) in pokemonTeam" :key="index" :pokemon="pokemon" />
        </div>
      </div>
      <div v-else>
        <p>No tienes ningún Pokémon en tu equipo</p> 
      </div>
      <div>
        <button @click="editarEquipo">Nuevo Equipo</button>
      </div>
    </main>
  </div>
</template>

<script>
import HeaderComponent from '@/components/Header.vue';
import PokemonCard from '@/components/CartaUsuario.vue';

export default {
    components: {
    HeaderComponent,
    PokemonCard,
},
    data() {
        return {
            pokemonTotal: [],
            pokemonTeam: [],
            pokemonList: [],
            loading: true,
            mostrarPopup: false,
            usuario: localStorage.getItem('token') ? true : false
        };
    },
    created() {
        this.fetchPokemonData();
    },
    methods: {
        fetchPokemonData() {
            var myHeaders = new Headers();
            myHeaders.append("Authorization", localStorage.getItem('token'));

            var requestOptions = {
                method: 'GET',
                headers: myHeaders,
                redirect: 'follow'
            };
            
            this.loading = true;

            fetch("http://localhost:3000/api/users/pokemons", requestOptions)
                .then(response => response.json())
                .then(data => {
                  this.pokemonTotal = data;
                  this.pokemonTeam = data.filter(pokemon => pokemon.team === true);
                  this.pokemonNoTeam = data.filter(pokemon => pokemon.team === false);
                })
                .catch(error => {
                    console.error('Error fetching Pokemon data:', error);
                })
                .finally(() => {
                    setTimeout(() => {
                        this.loading = false;
                    }, 1000);
                });
        },
        editarEquipo() {
          this.$router.push({ name: 'select-pokemon' });
        }
    }
};
</script>


<style>
main {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.title {
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 3.5rem;
  height: 60px;
  font-weight: bold;
  color: #ff2323;
  padding-bottom: 10px;
  margin-bottom: 30px;
  text-shadow: 2px 2px 5px #ff7575;
}

#chat-container {
  border: 2px solid #ff7575;
  background-color: #ff7575;
  box-shadow: 0 0 5px #ff7575;
  padding: 20px 20px 0 20px;
  margin: 50px;
}

.mensaje {
  padding: 5px;
}

.mensaje-usuario-actual {
  text-align: right;  
}

#enviar {
  margin-top: 20px;

  & button {
    border: none;
    text-decoration: none;
    color: black;
    font-size: 12px;
    font-weight: bold;
    background-color: #D9D9D9;
    padding: 10px 15px;
    margin-left: 10px;
  }

  & button:hover {
    background-color: #d2c8c8;
    cursor: pointer;
  }
}

.errorSesion {
  display: flex;
  justify-content: center;
  align-items: top;
  height: 400px;

  p {
    font-size: 1.5rem;
    color: #ff2323;
    text-shadow: 2px 2px 5px #ff7575;
  }
}
</style>