<script setup>
    import HeaderComponent from '@/components/Header.vue'
</script>

<template>
    <HeaderComponent />
    <main>
        <div class="title">
            <p>Registro</p>
        </div>
        <div id="form">
            <form @submit.prevent="registrarUsuario">
                <label for="nombre">
                    <input type="text" id="nombre" v-model="usuario.nombre" placeholder="Nombre" required />
                </label>
                <label for="correo">
                    <input type="email" id="correo" v-model="usuario.email" placeholder="Email" required />
                </label>
                <label for="contrasena">
                    <input type="password" id="contrasena" v-model="usuario.password" placeholder="Contraseña" required />
                </label>
                <button class="registrar" type="submit">Registrar</button>
                <div id="login">
                    <p>¿Ya tienes una cuenta?</p>
                    <RouterLink class="registrar" to="/iniciar-sesion">Inicia Sesión aquí</RouterLink>
                </div>
            </form>
        </div>
    </main>
</template>

<script>
export default {
    data() {
        return {
            usuario: {
                nombre: "",
                email: "",
                password: ""
            }
        };
    },
    methods: {
        registrarUsuario() {
            var myHeaders = new Headers();
            myHeaders.append("Content-Type", "application/json");

            var raw = JSON.stringify({
                "name": this.usuario.nombre,
                "email": this.usuario.email,
                "password": this.usuario.password,
                "isAdmin": false,
                "points": 0,
                "pokemons": []
            });


            var requestOptions = {
                method: 'POST',
                headers: myHeaders,
                body: raw,
                redirect: 'follow',
            };

            fetch("http://localhost:3000/api/users/register", requestOptions)
                .then(response => response.text())
                .then(result => {
                    if (result === 'User already exists') {
                        this.$router.push({ name: 'registrar-usuario' });
                    } else {
                        this.$router.push({ name: 'iniciar-sesion' });
                    }
                })
                .catch(error => console.log('error', error));
        }
    }
}
</script>

<style>
main {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

.title {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 3.5rem;
    height: 60px;
    font-weight: bold;
    color: #ff2323;
    padding-bottom: 10px;
    margin-bottom: 30px;
    text-shadow: 2px 2px 5px #ff7575;
}

#form {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 50px;
    box-shadow: 0 0 5px #ff7575;
}

form {
    font-family: 'Roboto', sans-serif;
    display: flex;
    flex-direction: column;
    align-items: center;
    background-color: #ff7575;
    padding: 30px;
}

input {
    height: 40px;
    width: 20rem;
    margin-bottom: 20px;
    background-color: #D9D9D9;
    border: none;
    font-size: 12px;
    font-weight: bold;
    outline: none;
    padding-left: 20px;
}

input:focus {
    background-color: #d2c8c8;
}

input::placeholder {
    color: #000000;
}

.registrar {
    align-self: flex-end;
    border: none;
    font-weight: bold;
    font-size: 12px;
    padding: 10px 20px;
    background-color: #D9D9D9;
}

.registrar:hover {
    background-color: #d2c8c8;
    cursor: pointer;
}

#login {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin-top: 80px;

    & p {
        font-size: 13px;
        font-weight: bold;
    }

    & .registrar {
        text-decoration: none;
        color: black;
        font-size: 13px;
        font-weight: bold;
        background-color: #D9D9D9;
        padding: 10px 20px;
    }

    & .registrar:hover {
        background-color: #d2c8c8;
        cursor: pointer;
    }
}
</style>