<template>
    <div id="app">
        <HeaderComponent />
        <main>
            <div class="title">
                <p>Batallas</p>
            </div>
            <div v-if="user" class="container">
                <div class="equipo" id="equipoUsuario">
                    <p class="titleteam">Tu equipo</p>
                    <div class="card-container">
                        <PokemonCard v-for="(pokemon, index) in pokemonTeam" :key="index" :pokemon="pokemon" />
                    </div>
                </div>
                <div class="equipo">
                    <p class="titleteam">Rival</p>
                    <div class="card-container">
                        <PokemonRandom v-for="index in 6" :key="index" :pokemonId="generateRandomPokemonId()"
                            :addToDatabase="false" />
                    </div>
                </div>
                <div id="botonBatalla">
                    <button @click="startBattle">¡A la batalla!</button>
                </div>
                <div>
                    <button class="button" @click="actualizar">Cambiar rival</button>
                </div> 
            </div>
            <div v-else>
                <p class="error">Debes iniciar sesión para ver esta página.</p>
            </div>
        </main>
    </div>
</template>

<script>
import HeaderComponent from '@/components/Header.vue';
import PokemonCard from '@/components/CartaUsuario.vue';
import PokemonRandom from '@/components/CartaRandom.vue';

export default {
    components: {
        HeaderComponent,
        PokemonCard,
        PokemonRandom
    },
    data() {
        return {
            pokemonTeam: [],
            pokemonRivalStats: [],
            pokemonTeamStats: [],
            battleStarted: false,
            battleCount: 1,
            roundCount: 0,
            teamWins: 0,
            attacker: null,
            defender: null,
            user: localStorage.getItem('token') ? true : false
        };
    },
    created() {
        this.fetchPokemonData();
    },
    methods: {
        fetchPokemonData() {
            var myHeaders = new Headers();
            myHeaders.append("Authorization", localStorage.getItem('token'));

            var requestOptions = {
                method: 'GET',
                headers: myHeaders,
                redirect: 'follow'
            };

            fetch("http://localhost:3000/api/users/pokemons", requestOptions)
                .then(response => response.json())
                .then(data => {
                    this.pokemonTeam = data.filter(pokemon => pokemon.team === true);
                    this.pokemonTeam.forEach(pokemon => {
                        const stats = {
                            name: pokemon.name,
                            attack: pokemon.stats.attack,
                            defense: pokemon.stats.defense,
                            hp: pokemon.stats.hp,
                        };
                        this.pokemonTeamStats.push(stats);
                    });
                })
                .catch(error => {
                    console.error('Error fetching Pokemon data:', error);
                });
        },

        generateRandomPokemonId() {
            const id = Math.floor(Math.random() * 800) + 1;
            this.saveStats(id);
            return id;
        },

        async saveStats(id) {
            const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
            const data = await response.json();
            const stats = {
                name: data.name,
                attack: data.stats[1].base_stat,
                defense: data.stats[2].base_stat,
                hp: data.stats[0].base_stat
            };
            this.pokemonRivalStats.push(stats);
        },

        startBattle() {
            this.battleStarted = true;
            this.battleRound(0);
        },

        async battleRound(index) {
            if (this.attacker == null) {
                this.attacker = this.pokemonTeamStats[index];
                this.defender = this.pokemonRivalStats[index];
            }

            this.roundCount++;

            if (this.attacker.attack > this.defender.defense) {
                this.defender.hp -= (this.attacker.attack - this.defender.defense);
            } else {
                this.defender.hp -= 5;
            }

            if (this.defender.hp <= 0) {
                if (this.roundCount % 2 === 0) {
                    alert('¡El equipo rival gana la ronda ' + this.battleCount + "!")
                } else {
                    alert('¡Tu equipo gana la ronda ' + this.battleCount + "!")
                    this.teamWins++;
                }
                if (this.battleCount === 6) {
                    if (this.teamWins > 3) {
                        await this.addPoints(100);
                        alert('¡Tu equipo ha ganado la batalla! Y has ganado 100 puntos.');
                    } else if (this.teamWins === 3) {
                        await this.addPoints(50);
                        alert('¡Empate!, Has ganado 50 puntos.');
                    } else {
                        alert('¡El equipo rival ha ganado la batalla!');
                    }
                    return;
                } else {
                    this.attacker = null;
                    this.defender = null;
                    this.roundCount = 0;
                    this.battleCount++;
                    this.battleRound(index + 1);
                }
            } else {
                [this.attacker, this.defender] = [this.defender, this.attacker];
                this.battleRound(index);
            }
        },

        addPoints(points) {
            var myHeaders = new Headers();
            myHeaders.append("Authorization", localStorage.getItem('token'));
            myHeaders.append("Content-Type", "application/json");

            var raw = JSON.stringify({
                "points": points
            });

            var requestOptions = {
                method: 'POST',
                headers: myHeaders,
                body: raw,
                redirect: 'follow'
            };

            fetch("http://localhost:3000/api/users/points/add", requestOptions)
                .then(response => response.text())
                .then(result => console.log(result))
                .catch(error => console.error('Error adding points to user:', error));
        }, 
        actualizar() {
            window.location.reload();
        }
    }
};
</script>

<style>
main {
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.title {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 3.5rem;
    height: 60px;
    font-weight: bold;
    color: #ff2323;
    padding-bottom: 10px;
    margin-bottom: 30px;
    text-shadow: 2px 2px 5px #ff7575;
}

.container {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.equipo {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 30px;

    .titleteam {
        font-size: 2rem;
        font-weight: bold;
        color: #ff2323;
        text-shadow: 2px 2px 5px #ff7575;
    }
}

#botonBatalla {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 30px;

    button {
        font-size: 2rem;
        font-weight: bold;
        color: white;
        background-color: #ff7575;
        border: none;
        border-radius: 10px;
        padding: 10px 20px;
        box-shadow: 0 0 10px #ff7575;
        transition: background-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out, transform 0.3s ease-in-out;

        &:hover {
            background-color: #ff2323;
            box-shadow: 0 0 10px #ff2323;
            transform: scale(1.05);
        }
    }
}
</style>