<script setup>
    import HeaderComponent from '@/components/Header.vue'
</script>

<template>
    <HeaderComponent />
    <main>
        <div class="title">
            <p>Usuario</p>
        </div>
        <div class="edit">
            <button @click="editUser" class="button">Editar Usuario</button>
        </div>
        <div class="log-out">
            <button @click="logOut" class="button">Cerrar Sesión</button>
        </div>
    </main>
</template>

<script>
export default {
    methods: {
        logOut() {
            localStorage.removeItem('token');
            localStorage.removeItem('name');
            localStorage.removeItem('id')
            this.$router.push({ name: 'iniciar-sesion' });
    },
        editUser() {
            this.$router.push({ name: 'edit-user' });
    }
  }
};
</script>

<style>
main {
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.title {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 3.5rem;
    height: 60px;
    font-weight: bold;
    color: #ff2323;
    padding-bottom: 10px;
    margin-bottom: 30px;
    text-shadow: 2px 2px 5px #ff7575;
}

.log-out, .edit {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 20px 0px;

    .button {
        border: none;
        text-decoration: none;
        color: black;
        border-radius: 3px;
        font-size: 12px;
        font-weight: bold;
        background-color: #ff7575;
        padding: 15px;
        margin-left: 10px;
        transition: background-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out; 
    }

    & button:hover {
        background-color: #ff2323;
        cursor: pointer;
        box-shadow: 0 0 5px #ff2323;
    }
}
</style>