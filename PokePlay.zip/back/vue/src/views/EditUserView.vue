<script setup>
import HeaderComponent from '@/components/Header.vue'
</script>

<template>
    <HeaderComponent />
    <main>
        <div class="title">
            <p>Usuario</p>
        </div>
        <div id="container-edit" class="form-container">
            <label for="name">Nombre:</label>
            <input type="text" id="name" v-model="name" />
            <label for="email">Email:</label>
            <input type="text" id="email" v-model="email" />
            <label for="password">Contraseña:</label>
            <input type="password" id="password" v-model="password" />
            <button @click="editUser" class="button">Editar</button>
        </div>
        <div v-if="updated">
            <p class="error">Usuario actualizado correctamente</p>
        </div>
        <div v-if="error">
            <p class="error">Error al actualizar el usuario</p>
        </div>
        <button @click="volver" class="button" id="volver">Volver</button>
    </main>
</template>

<script>
export default {
    data() {
        return {
            name: "",
            email: "",
            password: "",
            updated: false,
            error: false
        };
    },
    mounted() {
        this.getInfo();
    },
    methods: {
        getInfo() {
            const myHeaders = new Headers();
            myHeaders.append("Authorization", localStorage.getItem("token"));

            const requestOptions = {
                method: "GET",
                headers: myHeaders,
                redirect: "follow"
            };

            fetch("http://localhost:3000/api/users/" + localStorage.getItem('id'), requestOptions)
                .then((response) => response.text())
                .then((result) => {
                    result = JSON.parse(result);
                    this.name = result.name;
                    this.email = result.email;
                    this.password = result.password;
                })
                .catch((error) => console.error(error));
        },
        editUser() {
            const myHeaders = new Headers();
            myHeaders.append("Authorization", localStorage.getItem("token"));
            myHeaders.append("Content-Type", "application/json");

            const raw = JSON.stringify({
                name: this.name,
                email: this.email,
                password: this.password
            });

            const requestOptions = {
                method: "PUT",
                headers: myHeaders,
                body: raw,
                redirect: "follow"
            };

            fetch("http://localhost:3000/api/users/" + localStorage.getItem('id'), requestOptions)
                .then((response) => response.text())
                .then((result) => {
                    if (result) {
                        this.updated = true;
                        localStorage.setItem("name", this.name);
                    } else {
                        this.error = true;
                    }
                })
                .catch((error) => console.error("error", error));
        },
        volver() {
            this.$router.push({ name: "user" });
        }
    }
}
</script>


<style scoped>
main {
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.title {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 3.5rem;
    height: 60px;
    font-weight: bold;
    color: #ff2323;
    padding-bottom: 10px;
    margin-bottom: 30px;
    text-shadow: 2px 2px 5px #ff7575;
}

.form-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    border: 2px solid #ff2323;
    border-radius: 2px;
    padding: 20px;
    box-shadow: 0 0 5px #ff7575;
}

.form-container label {
    color: #ff2323;
    font-weight: bold;
    margin-bottom: 5px;
}

.form-container input[type="text"],
.form-container input[type="password"] {
    height: 40px;
    width: 20rem;
    margin-bottom: 20px;
    background-color: #D9D9D9;
    border: none;
    font-size: 12px;
    font-weight: bold;
    outline: none;
    padding-left: 20px;
}

.form-container input:focus {
    background-color: #d2c8c8;
}

.form-container button {
    border: none;
    font-weight: bold;
    font-size: 12px;
    padding: 10px 20px;
    background-color: #ff7575;
    color: white;
    cursor: pointer;
    transition: background-color 0.3s;
}

.form-container button:hover {
    background-color: #ff2323;
}

.error {
    font-size: 1.3rem;
    color: #ff2323;
    text-shadow: 2px 2px 5px #ff7575;
}

#error {
    color: #ff2323;
    font-size: 1.3rem;
    text-shadow: 2px 2px 5px #ff7575;
    margin-top: 20px;
    text-align: center;
    font-weight: bold;
}

#volver {
    margin-top: 20px;
    width: 230px;
}
</style>

