<script setup>
import HeaderComponent from '@/components/Header.vue'
</script>

<template>
    <HeaderComponent />
    <main>
        <div class="title">
            <p>Select Pokemons Team</p>
        </div>
        <div id="pokemonsContainer">
            <PokemonCard v-for="(pokemon, index) in pokemonTotal" :class="{ 'selected': pokemon.selected }" :key="index"
                :pokemon="pokemon" @click="togglePokemonSelection(pokemon)" />
        </div>
        <button v-if="newTeam.length === 6" @click="createTeam" class="button margin">Crear Equipo</button>
        <router-link to="/mi-equipo">
            <button class="button margin">Volver</button>
        </router-link>
    </main>
</template>

<script>
import HeaderComponent from '@/components/Header.vue';
import PokemonCard from '@/components/CartaUsuario.vue';

export default {
    components: {
        HeaderComponent,
        PokemonCard,
    },
    data() {
        return {
            pokemonTotal: [],
            newTeam: []
        };
    },
    created() {
        this.fetchPokemonData();
    },
    methods: {
        fetchPokemonData() {
            var myHeaders = new Headers();
            myHeaders.append("Authorization", localStorage.getItem('token'));

            var requestOptions = {
                method: 'GET',
                headers: myHeaders,
                redirect: 'follow'
            };
            this.loading = true;

            fetch("http://localhost:3000/api/users/pokemons", requestOptions)
                .then(response => response.json())
                .then(data => {
                    this.pokemonTotal = data.map(pokemon => ({ ...pokemon, selected: false }));
                })
                .catch(error => {
                    console.error('Error fetching Pokemon data:', error);
                })
        },
        togglePokemonSelection(pokemon) {
            if (pokemon.selected) {
                // Deseleccionar el Pokémon
                pokemon.selected = false;
                this.newTeam = this.newTeam.filter(p => p !== pokemon);
            } else {
                // Seleccionar el Pokémon si el equipo aún no está lleno
                if (this.newTeam.length < 6 || this.newTeam.includes(pokemon)) {
                    pokemon.selected = true;
                    this.newTeam.push(pokemon);
                } else {
                    // Deseleccionar el primer Pokémon seleccionado y seleccionar el nuevo
                    const deselectedPokemon = this.newTeam.shift();
                    deselectedPokemon.selected = false;
                    pokemon.selected = true;
                    this.newTeam.push(pokemon);
                }
            }
        },
        createTeam() {
            let pokemons = this.pokemonTotal;
            pokemons.forEach(pokemon => {
                pokemon.team = this.newTeam.includes(pokemon);
            });
            const myHeaders = new Headers();
            myHeaders.append("Authorization", localStorage.getItem("token"));
            myHeaders.append("Content-Type", "application/json");

            const raw = JSON.stringify({
                pokemons
            });

            const requestOptions = {
                method: "POST",
                headers: myHeaders,
                body: raw,
                redirect: "follow"
            };

            fetch("http://localhost:3000/api/users/pokemons/update", requestOptions)
                .then((response) => response.text())
                .then((result) => {
                    if (result ===  'Pokemons updated successfully') {
                        alert('Equipo actualizado correctamente');
                        this.$router.push('/mi-equipo');
                    }
                })
                .catch((error) => console.error(error));
        }
    }
};
</script>

<style>
main {
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.title {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 3.5rem;
    height: 60px;
    font-weight: bold;
    color: #ff2323;
    padding-bottom: 10px;
    margin-bottom: 30px;
    text-shadow: 2px 2px 5px #ff7575;
}

#pokemonsContainer {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
}

.selected {
    & .name {
        color: black;
    }

    & .stats {
        color: black;
    }
}

.margin {
    margin-top: 25px;
}

</style>