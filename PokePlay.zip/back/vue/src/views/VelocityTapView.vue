<template>
  <div>
    <HeaderComponent />
    <main>
      <div class="title">
        <p>Velocity Tap</p>
      </div>
      <div>
        <div v-if="!gameStarted" class="startButton">
          <button @click="startGame">¡A jugar!</button>
        </div>
        <TimerButton v-if="gameStarted" @timerFinished="handleTimerFinished" />
      </div>
    </main>
  </div>
</template>
  
<script>
import HeaderComponent from '@/components/Header.vue';
import TimerButton from '@/components/TimerButton.vue';

export default {
  components: {
    HeaderComponent,
    TimerButton,
  },
  data() {
    return {
      gameStarted: false,
      elapsedTime: 0,
      points: 0,
      user: localStorage.getItem('token') ? true : false
    };
  },
  methods: {
    startGame() {
      this.gameStarted = true;
    },
    calculatePoints(elapsedTime) {
      if (elapsedTime > 1000) {
        this.points = 0;
        return;
      }

      const pointsIntervals = [
        { interval: [0, 100], points: 100 },
        { interval: [101, 300], points: 80 },
        { interval: [301, 400], points: 60 },
        { interval: [401, 500], points: 50 },
        { interval: [501, 600], points: 40 },
        { interval: [601, 700], points: 30 },
        { interval: [701, 800], points: 20 },
        { interval: [801, 900], points: 10 },
        { interval: [901, 1000], points: 5 },
      ];

      let points = 0;
      for (const interval of pointsIntervals) {
        if (elapsedTime >= interval.interval[0] && elapsedTime <= interval.interval[1]) {
          points = interval.points;
          break;
        }
      }
      this.points = points;
      this.addPoints(this.points);
    },
    handleTimerFinished(timeDifference) {
      this.elapsedTime = timeDifference;
      if (this.user) {
        this.calculatePoints(this.elapsedTime);
        alert(`¡Felicidades! ¡Detuviste el temporizador!\nTiempo transcurrido: ${this.elapsedTime} milisegundos\nPuntos obtenidos: ${this.points}`);
      }
      else alert(`¡Felicidades! ¡Detuviste el temporizador!\nTiempo transcurrido: ${this.elapsedTime} milisegundos`)
      this.gameStarted = false;
    },
    async addPoints(points) {
      const token = localStorage.getItem('token');
      const myHeaders = new Headers();
      myHeaders.append("Authorization", token);
      myHeaders.append("Content-Type", "application/json");

      const raw = JSON.stringify({
        "points": points
      });

      const requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
      };

      try {
        await fetch("http://localhost:3000/api/users/points/add", requestOptions);
      } catch (error) {
        console.error('Error al restar puntos al usuario:', error);
      }
    }
  }
};
</script>

<style>
main {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.title {
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 3.5rem;
  height: 60px;
  font-weight: bold;
  color: #ff2323;
  padding-bottom: 10px;
  margin-bottom: 30px;
  text-shadow: 2px 2px 5px #ff7575;
}

.startButton {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;

  & button {
    padding: 10px 20px;
    font-size: 1.5rem;
    background-color: #ff7575;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: 0.5s;

    &:hover {
      background-color: #ff2323;
    }
  }
}
</style>