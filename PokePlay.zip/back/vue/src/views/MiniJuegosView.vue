<script setup>
    import HeaderComponent from '@/components/Header.vue'
</script>

<template>
    <HeaderComponent />
    <main>
        <div class="title">
            <p>MiniJuegos</p>
        </div>
        <div class="games-container">

        <RouterLink to="/guess-the-number" class="link">
            <div class="game">
                <p>Guess the number</p>   
            </div>
        </RouterLink>
        <RouterLink to="/velocity-tap" class="link">
        <div class="game">
            <p>Velocity Tap</p>
        </div>
        </RouterLink>
        <RouterLink to="/quick-clash" class="link">
            <div class="game">
                <p>Quick Clash</p>
            </div>
        </RouterLink>  
        </div>
    </main>
</template>

<style>
body {
    padding: 0;
    margin: 0;
}

main {
    display: flex;
    padding-top: 30px;
    flex-direction: column;
    justify-content: center;
}

.title {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 3.5rem;
    height: 60px;
    font-weight: bold;
    color: #ff2323;
    padding-bottom: 10px;
    margin-bottom: 30px;
    text-shadow: 2px 2px 5px #ff7575;
}

.games-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  max-width: 950px;
  max-height: 1100px;
  overflow-y: auto;
  margin: 0 auto; 
  height: 100%;
  gap: 30px;
  padding: 30px 0;
  margin-bottom: 30px;
  border: 2px solid #ff7575;
  box-shadow: 0 0 10px #ff7575;
  border-radius: 10px;
  background-color: #ff7575;
}

.game {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 300px;
  height: 350px;
  font-size: 2rem;
  font-weight: bold;
  color: #ff2323;
  border-radius: 10px;
  /*background-image: url('../assets/memory.jpg');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;*/
  background-color: #c8d6cd;
  transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;

  & p {
    background-color: black;
    color: white;
    width: 100%;
    text-align: center;
    margin: 0; 
    padding: 10px 0;
  }
}

.game:hover {
  transform: scale(1.1);
  box-shadow: 0 0 10px white;
  cursor: pointer;
}

.link {
    text-decoration: none;
}

</style>