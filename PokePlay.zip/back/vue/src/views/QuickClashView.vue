<template>
  <div>
    <HeaderComponent />
    <main>
      <div class="title">
        <p>Quick Clash</p>
      </div>
      <div class="equipo" id="equipoUsuario">
        <p class="titleteam">Equipo 1</p>
        <div class="card-container">
          <PokemonRandom v-for="index in 6" :key="index" :pokemonId="generateRandomPokemonId(1)" :addToDatabase="false" />
        </div>
      </div>
      <div class="equipo">
        <p class="titleteam">Equipo 2</p>
        <div class="card-container">
          <PokemonRandom v-for="index in 6" :key="index" :pokemonId="generateRandomPokemonId(2)" :addToDatabase="false" />
        </div>
      </div>
      <div class="selectEquipo">
        <label for="selectEquipo">Selecciona tu equipo: </label>
        <select id="selectEquipo" v-model="selectedTeam" @change="equipo">
          <option value="0">Selecciona un equipo</option>
          <option value="1">Equipo 1</option>
          <option value="2">Equipo 2</option>
        </select>
      </div>
      <div id="botonBatalla" v-if="conEquipo">
        <button @click="startBattle">¡A la batalla!</button>
      </div>
      <div>
        <button class="button" @click="actualizarEquipos">Actualizar equipos</button>
      </div>
    </main>
  </div>
</template>
  
<script>
import HeaderComponent from '@/components/Header.vue';
import PokemonCard from '@/components/CartaUsuario.vue';
import PokemonRandom from '@/components/CartaRandom.vue';

export default {
    components: {
        HeaderComponent,
        PokemonCard,
        PokemonRandom
    },
    data() {
        return {
          stats1: [],
          stats2: [],
          conEquipo: false,
          selectedTeam: "0",
          user: localStorage.getItem('token') ? true : false,
        };
    },
    methods: {
        equipo() {
          if (document.getElementById('selectEquipo').value !== "0") {
            this.conEquipo = true;
          } else {
            this.conEquipo = false;
          }
        },
        generateRandomPokemonId(team) {
            const id = Math.floor(Math.random() * 800) + 1;
            this.saveStats(id, team);
            return id;
        },
        async saveStats(id, team) {
            const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
            const data = await response.json();
            const stats = {
                attack: data.stats[1].base_stat,
                defense: data.stats[2].base_stat,
                hp: data.stats[0].base_stat
            };
            if (team === 1) {
                this.stats1.push(stats);
            } else {
                this.stats2.push(stats);
            }
        }, 
        startBattle() {
          let resultado = 0;
          this.stats1.forEach((pokemon, index) => {
            resultado += pokemon.attack + pokemon.defense + pokemon.hp - this.stats2[index].attack - this.stats2[index].defense - this.stats2[index].hp;
          });   
          const team = document.getElementById('selectEquipo').value; 
          let ganador = resultado > 0 ? 1 : (resultado === 0 ? 0 : 2);
          switch (ganador) {
            case 1:
              if (team === "1") {
                if(this.user) {
                  alert("¡Felicidades! Has ganado la batalla\nHas obtenido 100 puntos!");
                  this.addPoints(100);
                } else {
                  alert("¡Felicidades! Has ganado la batalla");
                }
              } else {
                if(this.user) {
                  alert("¡Lo siento! Has perdido la batalla\nNo has ganado puntos");
                } else {
                  alert("¡Lo siento! Has perdido la batalla");
                }
              }
              break;
            case 2:
              if (team === "2") {
                if(this.user) {
                  alert("¡Felicidades! Has ganado la batalla\nHas obtenido 100 puntos!");
                  this.addPoints(100);
                } else {
                  alert("¡Felicidades! Has ganado la batalla");
                }
              } else {
                if(this.user) {
                  alert("¡Lo siento! Has perdido la batalla\nNo has ganado puntos");
                } else {
                  alert("¡Lo siento! Has perdido la batalla");
                }
              }
              break;
            case 0:
              if(this.user) {
                alert("¡Empate! Has obtenido 50 puntos");
                this.addPoints(50);
              } else {
                alert("¡Empate!");
              }
              break;
          }
        },
        addPoints(points) {
            var myHeaders = new Headers();
            myHeaders.append("Authorization", localStorage.getItem('token'));
            myHeaders.append("Content-Type", "application/json");

            var raw = JSON.stringify({
                "points": points
            });

            var requestOptions = {
                method: 'POST',
                headers: myHeaders,
                body: raw,
                redirect: 'follow'
            };

            fetch("http://localhost:3000/api/users/points/add", requestOptions)
                .then(response => response.text())
                .then(result => console.log(result))
                .catch(error => console.error('Error adding points to user:', error));
        },
        actualizarEquipos() {
          this.stats1 = [];
          this.stats2 = [];
          this.conEquipo = false;
          this.selectedTeam = "0";
          window.location.reload();
        }
    }
};
</script>

<style>
.selectEquipo {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 20px 0;

  & label {
    margin-right: 20px;
    font-size: 1.2rem;
    font-weight: bold;
    color: #ff2323;
  }
}

.selectEquipo select {
    padding: 10px;
    font-size: 16px;
    border: 2px solid #ff7575;
    border-radius: 5px;
    font-size: 15px;
    outline: none;
}

.selectEquipo select:focus{
    border-color: #ff2323;
}
</style>