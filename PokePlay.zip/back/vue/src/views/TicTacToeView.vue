<script setup>
    import HeaderComponent from '@/components/Header.vue'
</script>

<template>
    <HeaderComponent />
    <main>
        <div class="title">
            <p>Tic-Tac-Toe</p>
        </div>
    </main>
</template>

<style>
main {
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.title {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 3.5rem;
    height: 60px;
    font-weight: bold;
    color: #ff2323;
    padding-bottom: 10px;
    margin-bottom: 30px;
    text-shadow: 2px 2px 5px #ff7575;
}
</style>