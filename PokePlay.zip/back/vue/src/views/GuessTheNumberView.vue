<template>
    <HeaderComponent />
    <main>
        <div class="title">
            <p>Guess the number</p>
        </div>
        <p v-if="!gameOver">Intenta adivinar el número secreto (entre 1 y 100):</p>
        <p v-if="gameOver">¡Felicitaciones! Has adivinado el número {{ secretNumber }} en {{ attempts }} intentos.</p>
        <input type="number" v-model="guess" :disabled="gameOver">
        <button @click="checkGuess" :disabled="gameOver" class="button">Adivinar</button>
        <p v-if="feedback !== ''">{{ feedback }}</p>
        <p v-if="gameOver">Has obtenido {{ score }} puntos</p>
    </main>
</template>

<script>
import HeaderComponent from '@/components/Header.vue';
import { ref } from 'vue';

export default {
    components: {
        HeaderComponent
    },
    data() {
        return {
            secretNumber: Math.floor(Math.random() * 100) + 1,
            guess: null,
            attempts: 0,
            feedback: '',
            gameOver: false,
            score: 0
        };
    },
    methods: {
        checkGuess() {
            this.attempts++;
            if (this.guess === this.secretNumber) {
                this.feedback = `¡Correcto! El número era ${this.secretNumber}.`;
                this.gameOver = true;
                if(localStorage.getItem('token')) {
                    this.calculateScore();
                }
            } else if (this.guess < this.secretNumber) {
                this.feedback = 'El número es mayor.';
            } else {
                this.feedback = 'El número es menor.';
            }
        },
        calculateScore() {
            if (this.attempts === 1) {
                this.score = 300;
            } else if (this.attempts === 2) {
                this.score = 250;
            } else if (this.attempts === 3) {
                this.score = 200;
            } else if (this.attempts === 4) {
                this.score = 150;
            } else {
                this.score = Math.max(10, 150 - (this.attempts - 4) * 20);
            }
            this.addPoints(this.score);
        },
        addPoints(points) {
            var myHeaders = new Headers();
            myHeaders.append("Authorization", localStorage.getItem('token'));
            myHeaders.append("Content-Type", "application/json");

            var raw = JSON.stringify({
                "points": points
            });

            var requestOptions = {
                method: 'POST',
                headers: myHeaders,
                body: raw,
                redirect: 'follow'
            };

            fetch("http://localhost:3000/api/users/points/add", requestOptions)
                .then(response => response.text())
                .then(result => console.log('Points added to user:', result))
                .catch(error => console.error('Error adding points to user:', error));
        }
    }
};
</script>
