<template>
  <div>
    <HeaderComponent />
    <main>
      <div class="title">
        <p>Chat</p>
      </div>
      <div v-if="user" id="chat-container">
        <div id="mensajes-container">
          <div v-for="mensaje in mensajes" :key="mensaje.id" class="mensaje"
            :class="{ 'mensaje-usuario-actual': mensaje.usuario === user }">
            <p v-if="mensaje.usuario !== user">
              <strong>{{ mensaje.usuario }}:</strong> {{ mensaje.texto }}
            </p>
            <p v-else>
              <strong>tú: </strong>{{ mensaje.texto }}
            </p>
          </div>
        </div>
        <div id="enviar">
          <input type="text" placeholder="Escribe un mensaje" id="mensaje" />
          <button @click="enviarMensaje">Enviar</button>
        </div>
      </div>
      <div v-else class="error">
        <p>Debes iniciar sesión para poder chatear</p>
      </div>
    </main>
  </div>
</template>
  
<script setup>
import HeaderComponent from '@/components/Header.vue';
import { onMounted, ref } from 'vue';

let user;
let mensajes = ref([]);

if (localStorage.getItem('name')) {
  user = localStorage.getItem('name');
}

const ws = new WebSocket('ws://localhost:3000');
const token = localStorage.getItem('token');

ws.onmessage = (event) => {
  const datos = JSON.parse(event.data);

  mensajes.value.push({
    usuario: datos.usuario,
    texto: datos.mensaje,
  });
};

function enviarMensaje() {
  const mensajeTexto = document.getElementById('mensaje').value;
  if (mensajeTexto.trim() !== '') {
    ws.send(JSON.stringify({
      usuario: user,
      mensaje: mensajeTexto,
    }));

    var myHeaders = new Headers();
    myHeaders.append("Authorization", token);
    myHeaders.append("Content-Type", "application/json");

    var raw = JSON.stringify({
      "texto": mensajeTexto,
      "usuario": user
    });

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: raw,
      redirect: 'follow'
    };

    fetch("http://localhost:3000/api/users/messages", requestOptions)
      .then(response => response.text())
      .then(result => console.log(result))
      .catch(error => console.log('error', error));

    document.getElementById('mensaje').value = '';
  }
}

onMounted(async () => {
  try {
    const response = await fetch("http://localhost:3000/api/users/messages", {
      method: 'GET',
      headers: {
        "Authorization": token,
      },
    });

    const result = await response.json();
    mensajes.value = result;
  } catch (error) {
    console.error('Error al obtener mensajes:', error);
  }
});
</script>

<style>
main {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.title {
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 3.5rem;
  height: 60px;
  font-weight: bold;
  color: #ff2323;
  padding-bottom: 10px;
  padding-top: 30px;
  margin-bottom: 30px;
  text-shadow: 2px 2px 5px #ff7575;
}

#chat-container {
  border: 2px solid #ff7575;
  background-color: #ff7575;
  box-shadow: 0 0 5px #ff7575;
  padding: 20px 20px 0 20px;
  margin: 50px;
}

.mensaje {
  padding: 5px;
}

.mensaje-usuario-actual {
  text-align: right;
}

#enviar {
  margin-top: 20px;

  & button {
    border: none;
    text-decoration: none;
    color: black;
    font-size: 12px;
    font-weight: bold;
    background-color: #D9D9D9;
    padding: 10px 15px;
    margin-left: 10px;
  }

  & button:hover {
    background-color: #d2c8c8;
    cursor: pointer;
  }
}
</style>