<template>
    <div id="app">
        <HeaderComponent />
        <main>
            <div class="title">
                <p>Mi equipo</p>
            </div>
            <div v-if="usuario" id="pokemons-container">
                <div v-if="loading" class="loading-message">
                    <p>Cargando datos...</p>
                </div>
                <div v-else id="container">
                    <div class="card-container">
                        <PokemonCard v-for="(pokemon, index) in pokemonList" :key="index" :pokemon="pokemon" />
                    </div>
                    <div class="button-container">
                        <router-link to="/addPokemon">
                            <button class="button">Tienda de Cartas</button>
                        </router-link>
                    </div>
                </div>
                <div>
                    <p v-if="pokemonList.length === 0 && !loading" class="noPokemon">No tienes ningún Pokémon en tu equipo</p>
                </div>
                <div v-if="pokemonTotal.length > 0 && !loading" class="editTeam"> 
                    <router-link to="/editTeam">
                        <button class="button">Editar Equipo</button>
                    </router-link>
                </div> 
            </div>
            <div v-else class="error">
                <p>Debes iniciar sesión para poder ver tu equipo</p>
            </div>
        </main>
    </div>
</template>

<script>
import HeaderComponent from '@/components/Header.vue';
import PokemonCard from '@/components/CartaUsuario.vue';

export default {
    components: {
    HeaderComponent,
    PokemonCard,
},
    data() {
        return {
            pokemonTotal: [],
            pokemonList: [],
            loading: true,
            usuario: localStorage.getItem('token') ? true : false
        };
    },
    created() {
        this.fetchPokemonData();
    },
    methods: {
        fetchPokemonData() {
            var myHeaders = new Headers();
            myHeaders.append("Authorization", localStorage.getItem('token'));

            var requestOptions = {
                method: 'GET',
                headers: myHeaders,
                redirect: 'follow'
            };
            this.loading = true;

            fetch("http://localhost:3000/api/users/pokemons", requestOptions)
                .then(response => response.json())
                .then(data => {
                    this.pokemonTotal = data;
                    if (this.pokemonTotal.length === 0) {
                        return;
                    }
                    this.pokemonList = data.filter(pokemon => pokemon.team === true);
                })
                .catch(error => {
                    console.error('Error fetching Pokemon data:', error);
                })
                .finally(() => {
                    setTimeout(() => {
                        this.loading = false;
                    }, 1000);
                });
        }
    }
};
</script>


<style>


#container {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
}

.card-container {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    gap: 20px;
    margin-bottom: 50px;
}

.button{
    background-color: #ff7575;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    font-size: 1.5rem;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
}

.button:hover {
    background-color: #ff2323;
    box-shadow: 0 0 5px #ff2323;
}

.pokemon-card {
    transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
}

.pokemon-card:hover {
    transform: scale(1.05);
    box-shadow: 0 0 15px #ff2323;
}

.editTeam {
    display: flex;
    justify-content: center;
    align-items: center; 
    margin-top: 20px;
}

.loading-message {
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 2rem;
    color: #ff2323;
    text-shadow: 2px 2px 5px #ff7575;
    height: 100px;
}
</style>