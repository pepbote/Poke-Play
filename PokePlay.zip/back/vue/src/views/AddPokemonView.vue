<script setup>
import HeaderComponent from '@/components/Header.vue';
import { ref } from 'vue';
import CartaRandom from '@/components/CartaRandom.vue';

const mostrarCartas = ref(false);
const cartasObtenidas = ref([]);
const pokemonDataLoaded = ref(false);

const abrirSobre = async (puntosRequeridos, cantidadCartas) => {
  pokemonDataLoaded.value = false;
  const puntos = await obtenerPuntosUsuario();
  if (puntos >= puntosRequeridos) {
    mostrarCartas.value = true;
    restarPuntos(puntosRequeridos);
    generarCartasAleatorias(cantidadCartas);
  } else {
    alert('No tienes suficientes puntos para abrir este sobre. Tienes ' + puntos + ' puntos.');
  }
}

const obtenerPuntosUsuario = async () => {
  const token = localStorage.getItem('token');
  const myHeaders = new Headers();
  myHeaders.append("Authorization", token);

  const requestOptions = {
    method: 'GET',
    headers: myHeaders,
    redirect: 'follow'
  };

  try {
    const response = await fetch("http://localhost:3000/api/users/points", requestOptions);
    console.log(response)
    const result = await response.text();
    const points = JSON.parse(result).points;
    return points;
  } catch (error) {
    return 0;
  }
}

const restarPuntos = async (puntos) => {
  const token = localStorage.getItem('token');
  const myHeaders = new Headers();
  myHeaders.append("Authorization", token);
  myHeaders.append("Content-Type", "application/json");

  const raw = JSON.stringify({
    "points": -puntos
  });

  const requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: raw,
    redirect: 'follow'
  };

  try {
    const response = await fetch("http://localhost:3000/api/users/points/add", requestOptions);
    const result = await response.text();
  } catch (error) {
    console.error('Error al restar puntos al usuario:', error);
  }
}

const generarCartasAleatorias = (cantidadCartas) => {
  cartasObtenidas.value = [];
  for (let i = 0; i < cantidadCartas; i++) {
    const indiceAleatorio = Math.floor(Math.random() * 800) + 1;
    cartasObtenidas.value.push(indiceAleatorio);
  }

  setTimeout(() => {
    pokemonDataLoaded.value = true;
  }, 1000);
}
</script>

<template>
  <div>
    <HeaderComponent />
    <main>
      <div class="title">
        <p>PokeStore</p>
      </div>
      <div class="sobres-container">
        <div class="sobre1 sobres" @click="abrirSobre(150, 1)">
          <span>1 Pokémon</span>
          <div class="sobre">
            <p>150 puntos!</p>
          </div>
        </div>
        <div class="sobre2 sobres" @click="abrirSobre(225, 2)">
          <span>2 Pokémon</span>
          <div class="sobre">
            <p>225 puntos!</p>
          </div>
        </div>
        <div class="sobre3 sobres" @click="abrirSobre(300, 3)">
          <span>3 Pokémon</span>
          <div class="sobre">
            <p>300 puntos!</p>
          </div>
        </div>
      </div>
      <div v-if="mostrarCartas && pokemonDataLoaded" class="pokemons-container">
        <div class="title-2">Pokémons obtenidos</div>
        <div class="newPokemons">
          <div v-for="(carta, index) in cartasObtenidas" :key="index" class="newPokemon">
            <CartaRandom :pokemonId="carta" />
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<style>
main {
  display: flex;
  justify-content: center;
}

.title {
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 3.5rem;
  height: 60px;
  font-weight: bold;
  color: #ff2323;
  padding-bottom: 10px;
  margin-bottom: 50px;
  text-shadow: 2px 2px 5px #ff7575;
}

.sobres-container {
  display: flex;
  gap: 50px;
}

.sobres {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  & span {
    font-size: 1.4rem;
    padding-bottom: 5px;
  }
}

.sobre {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  /* background-image: url('../components/icons/sobre1.png'); */
  font-size: 1.5rem;
  padding: 20px;
  background-color: #ff7575;
  box-shadow: 0 0 5px #ff7575;
  border-radius: 2px;
  margin-bottom: 30px;
  text-shadow: 2px 2px 5px #ff7575;
  transition: background-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
}

.sobre:hover {
  background-color: #ff2323;
  box-shadow: 0 0 15px #ff2323;
  cursor: pointer;
}

.pokemons-container {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 30px 40px;
  margin-bottom: 30px;
  border: 2px solid #ff2323;
  border-radius: 5px;
  box-shadow: 0 0 10px #ff2323;
}

.title-2 {
  font-size: 2rem;
  padding-bottom: 20px;
  color: #ff7575;
  text-shadow: 1px 1px 2px black;
}

.newPokemons {
  display: flex;
  gap: 30px;
}

.newPokemon {
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
