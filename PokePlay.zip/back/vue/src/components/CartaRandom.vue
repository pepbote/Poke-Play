<template>
  <div id="container">
    <div class="pokemon-card">
      <div class="card-content">
        <p class="name">{{ pokemonName }}</p>
        <img :src="pokemonSprite" :alt="pokemonName">
        <div class="stats" @mouseover="showStats = true" @mouseleave="showStats = false">
          <span class="tooltip" v-show="showStats">A | D | HP</span>
          <span class="attack-value">{{ pokemonStats.attack }}</span><span> | </span>
          <span class="defense-value">{{ pokemonStats.defense }}</span><span> | </span>
          <span class="vida-value">{{ pokemonStats.hp }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      showStats: false,
      pokemonName: '',
      pokemonSprite: '',
      pokemonStats: {}
    };
  },
  props: {
    pokemonId: {
      type: Number,
      required: true
    },
    addToDatabase: {
      type: Boolean,
      default: true
    }
  },
  created() {
    this.fetchPokemonData();
  },
  methods: {
    async fetchPokemonData() {
      try {
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${this.pokemonId}`);
        const data = await response.json();
        this.pokemonName = data.name;
        this.pokemonSprite = data.sprites.front_default;
        this.pokemonStats = {
          attack: data.stats[1].base_stat,
          defense: data.stats[2].base_stat,
          hp: data.stats[0].base_stat
        };  
        if (this.addToDatabase) {
          this.addToDatabaseFunction();
        }
      } catch (error) {
        console.error('Error fetching Pokemon data:', error);
      }
    },
    addToDatabaseFunction() {
      var myHeaders = new Headers();
        myHeaders.append("Authorization", localStorage.getItem('token'));
        myHeaders.append("Content-Type", "application/json");

        var raw = JSON.stringify({
          "id": this.pokemonId,
          "name": this.pokemonName,
          "stats": this.pokemonStats,
          "img": this.pokemonSprite,
          "team": false
        });

        var requestOptions = {
          method: 'POST',
          headers: myHeaders,
          body: raw,
          redirect: 'follow'
        };

        fetch("http://localhost:3000/api/users/pokemons", requestOptions)
          .then(response => response.text())
          .then(result => console.log(result))
          .catch(error => console.log('error', error));
    }
  }
};
</script>


<style>
#container {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0;
  padding-bottom: 20px;
}

.pokemon-card {
  background: rgb(255, 255, 255);
  background: radial-gradient(circle, rgba(255, 255, 255, 1) 0%, rgba(255, 117, 117, 1) 79%, rgba(255, 0, 0, 0.5215336134453781) 100%);
  border-radius: 10px;
  text-align: center;
  margin: 0;
  padding: 10px 10px;
  box-shadow: 0 0 10px #ff7575;
  transition: border-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out, transform 0.3s ease-in-out;
}

.card-content {
  margin: 0 auto;
}

.name {
  font-size: 1.5rem;
  font-weight: bold;
  color: white;
  text-shadow: 2px 2px 5px #ff7575;
  margin: 0;
}

.stats {
  padding: 0;
  font-size: 1.2rem;
  justify-content: center;
  align-items: center;
  color: white;
  text-shadow: 2px 2px 5px #ff7575;
  margin: 0;
  position: relative;
  cursor: pointer;
  white-space: nowrap;
  transition: opacity 0.3s ease;
}

.tooltip {
  position: absolute;
  font-size: 15px;
  top: -30px;
  left: 50%;
  transform: translateX(-50%);
  background-color: rgba(0, 0, 0, 0.5);
  color: white;
  padding: 5px;
  border-radius: 5px;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.3s ease;
}

.stats:hover .tooltip {
  opacity: 1;
}

.attack-value,
.defense-value,
.vida-value {
  font-weight: bold;
}

.card-content img {
  margin-top: 5px;
  max-width: 100%;
  height: 150px;
  transition: transform 0.3s ease-in-out, filter 0.3s ease-in-out;
}

.pokemon-card:hover {
  & .card-content img {
    transform: scale(1.1);
    filter: drop-shadow(0 0 5px #000000);
  }
}
</style>