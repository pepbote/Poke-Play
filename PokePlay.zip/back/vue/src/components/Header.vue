<template>
    <header>
        <div id="header-container">
            <div class="logo-container">
                <img alt="logo" class="logo" src="@/assets/logo.svg" />
                <p class="pokeplay">PokéPlay</p>
            </div>
            <nav id="menu-container">
                <RouterLink to="/" class="link">Minijuegos</RouterLink>
                <RouterLink to="/batallas" class="link">Batallas</RouterLink>
                <RouterLink to="/mi-equipo" class="link">Mi equipo</RouterLink>
                <RouterLink to="/chat" class="link">Chat</RouterLink>
                <RouterLink v-if="!isLoggedIn" to="/iniciar-sesion" class="link">Iniciar sesión</RouterLink>
                <RouterLink v-if="isLoggedIn" to="/user" class="link">Usuario</RouterLink>
            </nav>
            <!--<div class="toggle-menu-mobile">
        <label class="label-toggle" for="toggle-menu">
          <img class="toggle-open" src="./assets/menu.svg" alt="Open Menu">
          <img class="toggle-close" src="./assets/close.svg" alt="Close Menu">
        </label>
        <input type="checkbox" id="toggle-menu" class="visually-hidden">
      </div>-->
        </div>
    </header>
</template>

<script>
export default {
  data() {
    return {
      isLoggedIn: localStorage.getItem('token') !== null
    };
  }
};
</script>

<style>
:root {
  --primary-color: #ff2323;
  --secondary-color: white;
  --tertiary-color: black;
}

html {
  padding: 0;
  margin: 0;
}

body {
  padding: 0;
  margin: 0;
}

#header-container {
  display: flex;
  background-color: #ff2323;
  color: white;
  padding: 10px;
  height: 100%;
}

.logo-container {
  flex: 1;
  display: flex;
  margin-left: 20px;
  color: black;

  img {
    width: 50px;
    height: 50px;
    margin-right: 10px;
  }

  & .logo,
  & .pokeplay {
    transition: transform 0.3s ease-in-out, filter 0.3s ease-in-out;
  }

  & .logo:hover {
    transform: scale(1.1);
    filter: drop-shadow(0 0 5px rgb(255, 255, 255));
  }

  & .pokeplay:hover {
    transform: scale(1.1);
  }
}

.visually-hidden {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
}

.label-toggle,
.toggle-menu {
  display: none;
}

#menu-container {
  display: flex;
  align-items: center;
  margin-right: 20px;

  .link {
    margin-left: 10px;
    text-decoration: none;
    color: black;
    padding: 10px;
    display: block;
    transition: background-color 0.3s ease-in-out, color 0.3s ease-in-out, box-shadow 0.3s ease-in-out, transform 0.3s ease-in-out;
    border-radius: 5px;
  }

  .link:hover {
    background-color: white;
    color: #ff2323;
    box-shadow: 0 0 5px rgb(255, 255, 255);
    transform: scale(1.1);
  }
}
</style>
