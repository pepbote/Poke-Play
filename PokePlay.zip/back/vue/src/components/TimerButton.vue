<template>
    <div>
      <button :style="{ backgroundColor: buttonColor }" @click="finalTime"></button>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        buttonColor: 'red',
        timeGreen: null
      };
    },
    mounted() {
      this.startTimer();
    },
    methods: {
      startTimer() {
        if (!this.timer) {
          this.timerDuration = Math.floor(Math.random() * (8 - 2 + 1) + 2);
        }
  
        this.timer = setInterval(() => {
          this.timerDuration -= 1;
          if (this.timerDuration <= 0) {
            this.buttonColor = 'green';
            clearInterval(this.timer);
            this.timeGreen = new Date(Date.now());
          }
        }, 1000);
      },
      finalTime() {
        if (this.timeGreen) {
          const finalTime = new Date(Date.now());
          const difference = finalTime.getTime() - this.timeGreen.getTime();
          this.$emit('timerFinished', difference); 
        } else {
          console.log('El botón verde aún no se ha pulsado.');
        }
      }
    }
  };
  </script>
  
  <style scoped>
  button {
    width: 200px;
    height: 200px;
    border-radius: 50%;
    border: none;
    cursor: pointer;
  }
  </style>
  