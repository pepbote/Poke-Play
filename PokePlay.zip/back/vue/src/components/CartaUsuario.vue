<template>
  <div class="pokemon-card">
    <div class="card-content">
      <p class="name">{{ pokemon.name }}</p>
      <img :src="pokemon.img" :alt="pokemon.name">
      <div class="stats" @mouseover="showStats = true" @mouseleave="showStats = false">
        <span class="tooltip" v-show="showStats">A | D | HP</span>
        <span class="attack-value">{{ pokemon.stats.attack }}</span><span> | </span>
        <span class="defense-value">{{ pokemon.stats.defense }}</span><span> | </span>
        <span class="vida-value">{{ pokemon.stats.hp }}</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    pokemon: Object
  },
  data() {
    return {
      showStats: false
    };
  }
};
</script>

<style>
  #container {
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0; 
    padding-bottom: 20px;
  }

  .pokemon-card {
    background: rgb(255,255,255);
    background: radial-gradient(circle, rgba(255,255,255,1) 0%, rgba(255,117,117,1) 79%, rgba(255,0,0,0.5215336134453781) 100%);
    border-radius: 10px;
    text-align: center;
    padding: 10px 10px;
    box-shadow: 0 0 10px #ff7575;
    transition: border-color 0.3s ease-in-out;
  }

  .card-content {
    margin: 0 auto;
  }

  .name {
    font-size: 1.5rem;
    font-weight: bold;
    color: white;
    text-shadow: 2px 2px 5px #ff7575;
    margin: 0;
  }

  .stats {
    padding: 0;
    font-size: 1.2rem;
    justify-content: center;
    align-items: center;
    color: white;
    text-shadow: 2px 2px 5px #ff7575;
    margin: 0; 
    position: relative;
    cursor: pointer;
    white-space: nowrap;
    transition: opacity 0.3s ease;
  }

  .tooltip {
    position: absolute;
    font-size: 15px;
    top: -30px;
    left: 50%;
    transform: translateX(-50%);
    background-color: rgba(0, 0, 0, 0.5);
    color: white;
    padding: 5px;
    border-radius: 5px;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
  }

  .stats:hover .tooltip {
    opacity: 1;
  }

  .attack-value,
  .defense-value,
  .vida-value {
    font-weight: bold;
  }

  .card-content img {
    margin-top: 5px;
    max-width: 100%;
    height: 150px;
    transition: transform 0.3s ease-in-out, filter 0.3s ease-in-out;
  }

  .pokemon-card:hover {
    & .card-content img {
    transform: scale(1.1);
    filter: drop-shadow(0 0 5px #000000);
    }
  }
</style>