import { createApp } from 'vue';

const eventBus = createApp({});

export default eventBus;