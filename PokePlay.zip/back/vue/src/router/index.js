import { createRouter, createWebHistory } from 'vue-router'
import MiniJuegos from '../views/MiniJuegosView.vue'
import Batallas from '../views/BatallasView.vue'
import MiEquipo from '../views/MiEquipoView.vue'
import IniciarSesion from '../views/IniciarSesionView.vue'
import RegistrarUsuario from '../views/RegistrarUsuarioView.vue'
import Chat from '../views/ChatView.vue'
import User from '../views/UserView.vue'
import EditUser from '../views/EditUserView.vue'
import GuessTheNumber from '../views/GuessTheNumberView.vue'
import VelocityTap from '../views/VelocityTapView.vue'
import QuickClash from '../views/QuickClashView.vue'
import TicTacToe from '../views/TicTacToeView.vue'
import EditTeam from '../views/EditTeamView.vue'
import AddPokemon from '../views/AddPokemonView.vue'
import SelectPokemon from '../views/SelectPokemonView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'mini-juegos',
      component: MiniJuegos
    },
    {
      path: '/batallas',
      name: 'batallas',
      component: Batallas
    },
    {
      path: '/mi-equipo',
      name: 'mi-equipo',
      component: MiEquipo
    },
    {
      path: '/iniciar-sesion',
      name: 'iniciar-sesion',
      component: IniciarSesion
    },
    {
      path: '/registrar-usuario',
      name: 'registrar-usuario',
      component: RegistrarUsuario
    },
    {
      path: '/chat',
      name: 'chat',
      component: Chat
    },
    {
      path: '/user',
      name: 'user',
      component: User
    },
    {
      path: '/edit-user',
      name: 'edit-user',
      component: EditUser
    },
    {
      path: '/guess-the-number',
      name: 'guess-the-number',
      component: GuessTheNumber
    },
    {
      path: '/velocity-tap',
      name: 'velocity-tap',
      component: VelocityTap
    },
    {
      path: '/quick-clash',
      name: 'quick-clash',
      component: QuickClash
    },
    {
      path: '/tic-tac-toe',
      name: 'tic-tac-toe',
      component: TicTacToe
    },
    {
      path: '/editTeam',
      name: 'edit-team',
      component: SelectPokemon
    },
    {
      path: '/addPokemon',
      name: 'add-pokemon',
      component: AddPokemon
    },
    // {
    //   path: '/selectPokemon',
    //   name: 'select-pokemon',
    //   component: SelectPokemon
    // }
  ]
})

export default router