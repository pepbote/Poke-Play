<template>
  <div>
    <div class="app">
      <router-view />
    </div>
    <footer>
      <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
      <div class="logo-container">
        <img alt="logo" class="logo" src="@/assets/logo.svg" />
        <p class="pokeplay">PokéPlay</p>
      </div>
      <div id="redes">
        <div class="bx-cookie-container">
          <i class='bx bx-cookie'></i>
          <div class="tooltip">Cookies y privacidad</div>
        </div> <i class='bx bxl-instagram'></i>
        <i class='bx bxl-facebook-square'></i>
        <i class='bx bxl-twitter'></i>
        <i class='bx bxl-linkedin-square'></i>
      </div>
    </footer>
  </div>
</template>

<script>
import router from './router';

export default {
    data() {
        return {
            isLoggedIn: localStorage.getItem('token') !== null
        };
    },
    components: { router }
};
</script>

<style>
body {
  padding: 0;
  margin: 0;
}

.app {
  min-height: 90vh;
}

footer {
  display: flex;
  background-color: var(--tertiary-color);
  padding: 30px;
  margin-top: 30px;

  & .pokeplay {
    color: var(--secondary-color);
  }

  & #redes {
    display: flex;
    align-items: center;
    justify-content: space-around;
    width: 200px;
  }

  & .bx {
    font-size: 1.5rem;
    color: var(--secondary-color);
    transition: color 0.3s ease-in-out;
  }

  & .bx:hover {
    color: var(--primary-color);
  }

  & .bx-cookie-container {
    position: relative;
    display: inline-block;
  }

  & .tooltip {
    position: absolute;
    top: -40px;
    left: 50%;
    transform: translateX(-50%);
    width: max-content;
    background-color: rgba(255, 255, 255, 0.9);
    padding: 10px;
    border: 1px solid #ccc;
    z-index: 1;
    font-size: 10px;
    color: #333;
    visibility: hidden;
    border-radius: 5px;
    opacity: 0;
    transition: visibility 0.3s, opacity 0.3s;
  }

  & .bx-cookie-container:hover .tooltip {
    visibility: visible;
    opacity: 1;
  }

}
</style>